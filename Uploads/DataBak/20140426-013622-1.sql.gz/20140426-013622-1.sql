-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : admin
-- 
-- Part : #1
-- Date : 2014-04-26 01:36:22
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `kl_addons`
-- -----------------------------
DROP TABLE IF EXISTS `kl_addons`;
CREATE TABLE `kl_addons` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` char(50) default NULL,
  `mark` char(50) default NULL,
  `version` char(50) default NULL,
  `author` char(50) default NULL,
  `descr` varchar(255) default NULL,
  `install` tinyint(1) NOT NULL default '1',
  `param` text,
  `status` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `kl_addons`
-- -----------------------------
INSERT INTO `kl_addons` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `kl_addons` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `kl_addons` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `kl_category`
-- -----------------------------
DROP TABLE IF EXISTS `kl_category`;
CREATE TABLE `kl_category` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL default '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL default '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL default '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL default '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL default '' COMMENT '关键字',
  `description` varchar(255) NOT NULL default '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL default '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL default '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL default '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL default '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL default '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL default '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL default '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL default '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL default '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL default '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL default '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL default '0' COMMENT '分类图标',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `kl_category`
-- -----------------------------
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `kl_channel`
-- -----------------------------
DROP TABLE IF EXISTS `kl_channel`;
CREATE TABLE `kl_channel` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL default '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL default '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL default '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL default '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL default '0' COMMENT '新窗口打开',
  PRIMARY KEY  (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `kl_channel`
-- -----------------------------
INSERT INTO `kl_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `kl_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `kl_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `kl_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `kl_channel` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `kl_config`
-- -----------------------------
DROP TABLE IF EXISTS `kl_config`;
CREATE TABLE `kl_config` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '配置ID',
  `name` varchar(30) NOT NULL default '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL default '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL default '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL default '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL default '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL default '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL default '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL default '0' COMMENT '排序',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `kl_config`
-- -----------------------------
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `kl_document`
-- -----------------------------
DROP TABLE IF EXISTS `kl_document`;
CREATE TABLE `kl_document` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL default '0' COMMENT '用户ID',
  `name` char(40) NOT NULL default '' COMMENT '标识',
  `title` char(80) NOT NULL default '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL default '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL default '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL default '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL default '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL default '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL default '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL default '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL default '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL default '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL default '1404432000' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL default '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL default '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL default '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL default '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL default '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL default '1404432000' COMMENT '开标时间',
  `update_time` int(10) unsigned NOT NULL default '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL default '0' COMMENT '数据状态',
  PRIMARY KEY  (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `kl_document`
-- -----------------------------
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `kl_file`
-- -----------------------------
DROP TABLE IF EXISTS `kl_file`;
CREATE TABLE `kl_file` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '文件ID',
  `name` char(30) NOT NULL default '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL default '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL default '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL default '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL default '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL default '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL default '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL default '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL default '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `kl_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `kl_hooks`;
CREATE TABLE `kl_hooks` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` char(12) NOT NULL,
  `mark` char(255) default NULL,
  `pluginid` varchar(255) default NULL,
  `descr` varchar(255) default NULL,
  `status` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `kl_hooks`
-- -----------------------------
INSERT INTO `kl_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `kl_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `kl_hooks` VALUES ('', '', '', '', '', '');

-- -----------------------------
-- Table structure for `kl_member`
-- -----------------------------
DROP TABLE IF EXISTS `kl_member`;
CREATE TABLE `kl_member` (
  `id` int(11) NOT NULL auto_increment,
  `groupid` int(11) default NULL,
  `username` char(32) default NULL,
  `password` char(32) default NULL,
  `email` char(32) default NULL,
  `mobile` char(32) default NULL,
  `reg_time` int(11) default NULL,
  `reg_ip` char(32) default NULL,
  `login` int(11) unsigned NOT NULL,
  `update_time` int(11) default NULL,
  `last_login_time` int(11) default NULL,
  `last_login_ip` char(12) default NULL,
  `status` tinyint(1) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `kl_member`
-- -----------------------------
INSERT INTO `kl_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `kl_member_group`
-- -----------------------------
DROP TABLE IF EXISTS `kl_member_group`;
CREATE TABLE `kl_member_group` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '用户ID',
  `title` char(32) NOT NULL,
  `auth` text NOT NULL COMMENT '用户名',
  `status` tinyint(4) default '1' COMMENT '用户状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `kl_member_group`
-- -----------------------------
INSERT INTO `kl_member_group` VALUES ('', '', '', '');
INSERT INTO `kl_member_group` VALUES ('', '', '', '');
INSERT INTO `kl_member_group` VALUES ('', '', '', '');

-- -----------------------------
-- Table structure for `kl_menu`
-- -----------------------------
DROP TABLE IF EXISTS `kl_menu`;
CREATE TABLE `kl_menu` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '文档ID',
  `title` varchar(50) NOT NULL default '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL default '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL default '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL default '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL default '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL default '' COMMENT '提示',
  `group` varchar(50) NOT NULL default '默认分组' COMMENT '分组',
  `type` char(50) NOT NULL default 'system',
  `status` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `kl_menu`
-- -----------------------------
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `kl_menu` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `kl_picture`
-- -----------------------------
DROP TABLE IF EXISTS `kl_picture`;
CREATE TABLE `kl_picture` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '主键id自增',
  `path` varchar(255) NOT NULL default '' COMMENT '路径',
  `url` varchar(255) NOT NULL default '' COMMENT '图片链接',
  `md5` char(32) NOT NULL default '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL default '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL default '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL default '0' COMMENT '创建时间',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `kl_picture`
-- -----------------------------
INSERT INTO `kl_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `kl_picture` VALUES ('', '', '', '', '', '', '');
